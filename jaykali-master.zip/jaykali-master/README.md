### Hi there, I'm [Kali!](https://www.kalilinux.in) 

<p align="center">
  <img width="260" height="346" src="https://raw.githubusercontent.com/jaykali/jaykali/master/kali.gif">
</p>

## I'm Caring Mother, Fearless Warrior, Monster Killer, Cybersecurity Teacher!
 - 🔭 I’m currently working on my [Website](https://www.kalilinux.in)<img src="https://media.giphy.com/media/WUlplcMpOCEmTGBtBW/giphy.gif" width="50">
  - 🌱 I’m currently learning Everything.
  - 💬 Ask me about Cybersecurity.
  - 🥅 2025 Goals: Write lots of Infosec Articles on my [website](https://www.kalilinux.in).
  - ⚡ Fun fact: Kali & Kali Linux are not same, but both belives in Offencive Security.

### <img height="30" src="https://raw.githubusercontent.com/jaykali/jaykali/master/soulgem-homura.gif"/> Connect with me:

[<img align="left" alt="kalilinux.in" width="22px" src="https://raw.githubusercontent.com/iconic/open-iconic/master/svg/globe.svg" />][website]
[<img align="left" alt="kalilinuxIn | Twitter" width="22px" src="https://cdn.jsdelivr.net/npm/simple-icons@v3/icons/twitter.svg" />][twitter]
[<img align="left" alt="kalilinuxIn | Medium" width="22px" src="https://raw.githubusercontent.com/jaykali/jaykali/master/github.png" />][github]

<br />

### <img height="30" src="https://raw.githubusercontent.com/jaykali/jaykali/master/soulgem-sayaka.gif"/> 📕 Latest Blog Posts
<!-- BLOG-POST-LIST:START -->
- [Best USB WiFi Adapter For Kali Linux 2025 [Updated September]](https://www.kalilinux.in/best-usb-wifi-adapter-for-kali-linux/)
- [Right way to record and share our Terminal sessions](https://www.kalilinux.in/record-and-share-terminal/)
- [Dmitry — The Deep Magic](https://www.kalilinux.in/dmitry-the-deep-magic/)
- [Basics of Digital Forensics](https://www.kalilinux.in/digital-forensics/)
- [Top Linux Server Automation Tools: Simplifying System Administration](https://www.kalilinux.in/linux-server-automation-tool/)
<!-- BLOG-POST-LIST:END -->
<img width="250" height="250" src="https://raw.githubusercontent.com/jaykali/jaykali/master/kali%20dragon.gif"/>
<img src="https://github-readme-stats.vercel.app/api?username=jaykali&&show_icons=true&theme=radical&line_height=27&v=5" alt="JayKali's GitHub Stats" />
<p align="center"> 
  <b>Visitor count</b><br>
  <img src="https://profile-counter.glitch.me/jaykali/count.svg" />
</p>



[website]: https://www.kalilinux.in
[twitter]: https://twitter.com/KaliLinux_in
[github]: https://github.com/jaykali
