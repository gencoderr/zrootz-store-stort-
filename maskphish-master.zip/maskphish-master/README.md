<!-- Image -->
<p align="center">
	<img src="https://i.imgur.com/plp3lJu.jpg" width="650px" height="300px">
</p>

<!-- Tags - 1 -->
<p align = "center">
  <a href = "https://github.com/IoT-Buzz/IoT/issues">
    <img src = "https://img.shields.io/github/issues/jaykali/maskphish.svg" />
  </a>
  <a href = "https://github.com/IoT-Buzz/IoT/issues?q=is%3Aissue+is%3Aclosed">
    <img src = "https://img.shields.io/github/issues-closed/jaykali/maskphish.svg" />
  </a>
  <a href = "https://github.com/IoT-Buzz/IoT/pulls">
    <img src = "https://img.shields.io/github/issues-pr/jaykali/maskphish.svg" />
  </a>
  <a href = "https://github.com/IoT-Buzz/IoT/pulls?q=is%3Apr+is%3Aclosed">
    <img src = "https://img.shields.io/github/issues-pr-closed/jaykali/maskphish.svg" />
  </a>
  <a href = "">
    <img src = "https://img.shields.io/github/repo-size/jaykali/maskphish?color=yellow" />
  </a>
  <a href = "">
    <img src = "https://img.shields.io/tokei/lines/github/jaykali/maskphish?color=red&label=Lines%20of%20Code" />
  </a>
</p>

<!-- Tags - 2 -->
<p align = "center">
  <a href = "https://github.com/jaykali/maskphish/releases/tag/2.0">
      <img src = "https://img.shields.io/badge/MaskPhish-2.0-green" />	  
  </a>
  <a href = "https://twitter.com/KaliLinux_in">
      <img src = "https://img.shields.io/twitter/url/https/twitter.com/cloudposse.svg?style=social&label=Follow%20%40KaliLinux_in" />
  </a>
</p>

<!-- Author -->
<p align = "center">
     <h3 align = "center"> 👨‍💻️ Author : <a href = "https://github.com/jaykali"> jaykali </a> </h3>
</p>

<br />

## 🔥 MaskPhish
MaskPhish is not any Phishing tool. It's just a proof of concept of "URL Making Technology". It is a simple Bash Script to hide phishing URL under a normal looking URL (google.com or facebook.com). It can be integrated into Phishing tools (with proper credits) to look the URL ledgit.

<br />

## ⚖️ Legal Disclaimer:
**FOR EDUCATIONAL PURPOSES ONLY** <br />
Usage of MaskPhish for attacking targets without prior mutual consent is illegal. It's the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program. Use Responsibly!

<br />

## Common Issue
Sometimes Masked link is not generating properly. In that case we need to use VPN/proxy, then use maskphish to generate masked link.

## 💻 Installation 

```bash
# Clone the repository 
git clone https://github.com/jaykali/maskphish

# Enter into the directory
cd maskphish

# Run the script
bash maskphish.sh
```

<br />

- *Tested on Kali Linux, Termux & Ubuntu* <br />
- Detailed Article can be found [here](https://www.kalilinux.in/2020/07/how-to-hide-phishing-link.html)
- Want to discuss something? Start discussions [click here](https://github.com/jaykali/maskphish/discussions/new)

<br />

## 🖼️ Screenshot
<p align="">
	<img src="https://i.imgur.com/1JsWv4I.png" width="600px">
</p>

<br />

## ❤️ Contributors:
You can propose a feature request opening an issue or a pull request.
Here is a list of MaskPhish contributors:

<a href="https://github.com/jaykali/maskphish/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=jaykali/maskphish" />
</a>
