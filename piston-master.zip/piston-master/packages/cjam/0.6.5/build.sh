#!/usr/bin/env bash

# CJam depends on Java
source ../../java/15.0.2/build.sh

curl -L "https://downloads.sourceforge.net/project/cjam/cjam-0.6.5/cjam-0.6.5.jar?ts=gAAAAABgf6xp4bmSJmNMjz8z23zWVbRgW6mhaFrnxdBe_riqC4rZnhUpXJrQzPpSqhniaoGptfkI_r-tjjBc5326oRmloXIJYQ%3D%3D&r=https%3A%2F%2Fsourceforge.net%2Fprojects%2Fcjam%2Ffiles%2Fcjam-0.6.5%2Fcjam-0.6.5.jar%2Fdownload" -o bin/cjam.jar
