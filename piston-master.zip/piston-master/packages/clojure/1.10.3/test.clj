(ns clojure.examples.main
   (:gen-class))
(defn main []
   (println "OK"))
(main)