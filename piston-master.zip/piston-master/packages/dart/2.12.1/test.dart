void main() {
  print('OK');
}