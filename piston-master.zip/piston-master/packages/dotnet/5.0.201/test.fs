open System

[<EntryPoint>]
let main argv =
    printfn "OK"
    0
