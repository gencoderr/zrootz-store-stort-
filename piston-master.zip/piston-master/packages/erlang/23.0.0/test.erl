
main(_) ->
    io:format("OK~n").