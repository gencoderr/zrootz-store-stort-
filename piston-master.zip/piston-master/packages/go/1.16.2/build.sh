#!/usr/bin/env bash
curl -LO https://golang.org/dl/go1.16.2.linux-amd64.tar.gz
tar -xzf go1.16.2.linux-amd64.tar.gz
rm go1.16.2.linux-amd64.tar.gz

