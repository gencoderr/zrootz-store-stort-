#!/usr/bin/env bash

# japt install
source ../../node/16.3.0/build.sh

git clone -q "https://github.com/Hydrazer/japt.git" japt