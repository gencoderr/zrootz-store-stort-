fun main() {
    println("OK")
}
