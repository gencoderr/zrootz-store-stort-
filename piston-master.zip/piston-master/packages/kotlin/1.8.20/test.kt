fun main() {
    println("OK")
}