#!/bin/bash

source ../../python/3.9.1/build.sh

git clone -q https://github.com/betaveros/paradoc.git paradoc
