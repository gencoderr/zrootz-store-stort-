#!/usr/bin/env bash

# Pyth install
source ../../python/3.9.1/build.sh

git clone -q "https://github.com/isaacg1/pyth.git" pyth
