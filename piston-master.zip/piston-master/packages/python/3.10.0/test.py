working = True

match working:
    case True:
        print("OK")
    case False:
        print()
