#!/usr/bin/env bash

curl -OL "https://static.rust-lang.org/dist/rust-1.63.0-x86_64-unknown-linux-gnu.tar.gz"
tar xzvf rust-1.63.0-x86_64-unknown-linux-gnu.tar.gz
rm rust-1.63.0-x86_64-unknown-linux-gnu.tar.gz
