fn main() {
    println!("OK");
}