#!/bin/bash
source ../../python/3.10.0/build.sh
bin/pip3 install https://github.com/samarium-lang/Samarium/archive/refs/tags/0.3.1.zip
