@main def run(): Unit = {
  println("OK")
}