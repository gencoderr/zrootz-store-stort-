#!/usr/bin/env bash

source ../../node/15.10.0/build.sh

source ./environment

bin/npm install -g typescript@4.2.3
