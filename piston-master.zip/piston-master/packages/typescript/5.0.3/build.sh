#!/usr/bin/env bash

source ../../node/18.15.0/build.sh

source ./environment

bin/npm install -g typescript@5.0.3