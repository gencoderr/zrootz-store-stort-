#!/usr/bin/env bash

# Cloning vlang source
git clone https://github.com/vlang/v
cd v

# Building and installing vlang
make