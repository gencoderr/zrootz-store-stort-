li = ["N", "o", "t", "o", "k"]
yeet li[:3]
print(''.join(x.title() for x in li))
