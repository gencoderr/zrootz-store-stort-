# Exploit Tests

This directory contains a collection of exploits which have already been patched

Write exploits in any language supported by piston.

Hopefully when running any files in this directory, piston will resist the attack.

Leave a comment in the code describing how the exploit works.
