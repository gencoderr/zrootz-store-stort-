while True:
    print("Piston is secure")